// // Route::get('/acc/kas', [AccController::class, 'indexKas']);
// Route::post('/storekas', [AccController::class, 'storeKas']);
// Route::get('/detail/kas/{jurnal_id}/{id}', [AccController::class, 'detKas']);

// Route::post('/storesapis', [AccController::class, 'storesapis']);

// Route::post('/storeopr', [AccController::class, 'storeopr']);
// Route::post('/storetrans', [AccController::class, 'storetrans']);
// Route::post('/storepiutang', [AccController::class, 'storepiutang']);

// //stok sapi
// Route::get('/stoksapis', [AccController::class, 'stoksapis']);

// //update status sapi
// Route::put('/editstatus/{id}', [AccController::class, 'editstatus']);

// //total hutang
// Route::get('/total_hutang', [AccController::class, 'allhutang']);

// //pakan
// // Route::get('/acc/pakans', [AccController::class, 'indexpakans']);
// Route::post('/storepakans', [AccController::class, 'storepakans']);
// Route::post('/belipakans', [AccController::class, 'belipakans']);
// Route::post('/pemakaianpakans', [AccController::class, 'pemakaianpakans']);

// //hutang
// // Route::get('/acc/hutang', [AccController::class, 'indexhutang']);

// //piutang
// // Route::get('/acc/piutang', [AccController::class, 'indexpiutang']);

// //gaji
// Route::post('/inputsalary', [AccController::class, 'storesalary']);
// Route::post('/kasihkasbon', [AccController::class, 'storekashbon']);
// // Route::get('/acc/pekerja', [PekerjaController::class, 'index']);
// // Route::get('/acc/pekerja/{id}', [PekerjaController::class, 'detail_pekerja']);

// //customer
// // Route::get('/acc/customer', [CustomerController::class, 'index']);
// // Route::get('/acc/customer/{id}', [CustomerController::class, 'detail']);

// //suppliersapi
// // Route::get('/acc/supsapis', [SupSapiController::class, 'index']);

// //faktur
// Route::get('/faktur/{id}', [PDFController::class, 'fakturcust']);