<form action="/acc/hutang" method="post">
    @csrf
    <button type="submit" class="btn btn-primary">
</form>
