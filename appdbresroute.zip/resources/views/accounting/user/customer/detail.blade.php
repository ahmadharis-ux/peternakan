<div class="card recent-sales overflow-auto">
    <div class="card-title px-3">List Hutang customer</div>
    <div class="card-body">
        @include('accounting.user.customer.tableListPiutang')
    </div>
</div>

<div class="card recent-sales overflow-auto">
    <div class="card-title px-3">List Faktur customer</div>
    <div class="card-body">
        @include('accounting.user.tableListFakturPihakKedua')
    </div>
</div>
