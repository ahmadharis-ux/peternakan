<div class="card recent-sales overflow-auto">
    <div class="card-title px-3">List piutang supplier sapi</div>
    <div class="card-body">
        @include('accounting.user.supplier_sapi.tableListHutang')
    </div>
</div>

<div class="card recent-sales overflow-auto">
    <div class="card-title px-3">List Faktur supplier sapi</div>
    <div class="card-body">
        @include('accounting.user.tableListFakturPihakKedua')
    </div>
</div>
