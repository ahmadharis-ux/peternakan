@php

    // kredit
    $totalKreditPakan = $listDetailPembelian->sum('subtotal');
    $totalOperasional = $listOperasionalPembelian->sum('harga');
    $totalKredit = $totalKreditPakan + $totalOperasional;

    // pembayaran
    $totalBayar = $listRiwayatTransaksi->sum('nominal');
    $sisaPembayaran = $totalKredit - $totalBayar;
    $statusKredit = $kredit->lunas ? 'LUNAS' : 'BELUM LUNAS';

    // pihak kedua
    $pk = $kredit->pihakKedua;
    $pihakKeduaFullname = "$pk->nama_depan $pk->nama_belakang";

@endphp

<div class="row mt-3">
    <div class="col-sm">Pembelian pakan</div>
    <div class="col-sm d-flex justify-content-between">
        <span class="text-secondary">Rp</span>
        <span>
            {{ number_format($totalKreditPakan) }}
        </span>
    </div>
</div>

<div class="row">
    <div class="col-sm">Operasional</div>
    <div class="col-sm d-flex justify-content-between">
        <span class="text-secondary">Rp</span>
        <span>
            {{ number_format($totalOperasional) }}
        </span>
    </div>
</div>

<div class="row">
    <div class="col">
        <hr>
    </div>
    <div class="col-1">+</div>
</div>

<div class="row">
    <div class="col-sm">Total kredit</div>
    <div class="col-sm d-flex justify-content-between">
        <span class="text-secondary">Rp</span>
        <span class="">
            {{ number_format($totalKredit) }}
        </span>
    </div>
</div>

<div class="row">
    <div class="col-sm ">Tunai</div>
    <div class="col-sm d-flex justify-content-between">
        <span class="text-secondary">Rp</span>
        <span>
            -{{ number_format($totalBayar) }}
        </span>
    </div>
</div>

<div class="row fw-bold">
    <div class="col-sm ">Sisa kredit</div>
    <div class="col-sm d-flex justify-content-between">
        <span class="text-secondary">Rp</span>
        <span>
            {{ number_format($sisaPembayaran) }}
        </span>
    </div>
</div>
<hr>

<div class="row">
    <div class="col-sm">Status</div>
    <div class="col-sm d-flex justify-content-start">
        <span class="fw-bold">
            {{ $statusKredit }}
        </span>
    </div>
</div>

<div class="row">
    <div class="col-sm">Pihak kedua</div>
    <div class="col-sm d-flex justify-content-start">
        <span class="fw-bold">
            {{ $pihakKeduaFullname }}
        </span>
    </div>
</div>
